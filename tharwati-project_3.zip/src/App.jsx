import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Wallet, ArrowUpRight, ArrowDownLeft, RefreshCw, Plus, Trash2, Edit2, Copy, Check,
  Bell, Coins, FileSpreadsheet, StickyNote, Cloud, LogOut,
  ShieldCheck, Landmark, ArrowLeftRight, Globe, Calendar, HeartHandshake, Volume2, Clock
} from 'lucide-react';

import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, setDoc, onSnapshot } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "DEMO_KEY",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "tharwati-demo.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "tharwati-demo",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "tharwati-demo.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "000000000000",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:000000000000:web:000000000000"
};

let auth = null;
let db = null;
let googleProvider = null;

try {
  if (firebaseConfig.apiKey !== "DEMO_KEY") {
    const app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
    googleProvider = new GoogleAuthProvider();
  }
} catch (e) {
  console.warn("Firebase running in local-first mode.");
}

const translations = {
  en: {
    appName: "Tharwati",
    subtitle: "Smart Financial Management",
    dashboard: "Dashboard",
    transactionsTab: "Transactions",
    currencies: "Currencies",
    accounts: "Accounts",
    wealth: "Wealth",
    zakat: "Zakat & Charity",
    remindersTab: "Alarms & Reminders",
    notesTab: "Notes & Reports",
    totalLiquidity: "Total Liquidity",
    dailyExpense: "Today's Expenses",
    monthlyExpense: "Monthly Expenses",
    netWealth: "Total Net Wealth",
    recentTransactions: "Transactions Log",
    newTransaction: "New Transaction",
    expense: "Expense",
    income: "Income / Deposit",
    description: "Description (e.g. Coffee, Bill, Salary...)",
    amount: "Amount",
    saveTransaction: "Save Transaction",
    updateTransaction: "Update Transaction",
    smartConverter: "Smart Currency Converter",
    liveMarketRate: "Live Market Rate (Auto)",
    exchangeOfficeRate: "Exchange Office Rate (Manual ✍️)",
    amountToConvert: "Amount to convert",
    convertedResult: "Converted Result",
    instantRefresh: "Instant Refresh",
    recordAsTransaction: "Record result as transaction in my accounts",
    myAccounts: "My Bank Accounts",
    addNewAccount: "Add New Bank Account",
    editAccount: "Edit Account",
    accountName: "Account Name",
    bankName: "Bank Name",
    initialBalance: "Initial Balance",
    accountNumber: "Account Number",
    iban: "IBAN Number",
    saveAccount: "Save Account",
    updateAccount: "Update Account",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    zakatCalc: "Zakat Calculator (2.5%)",
    charityCalc: "Charity Calculator",
    nisab: "Zakat Nisab (85g 24k):",
    zakatDue: "Due Zakat (2.5%):",
    charityAmount: "Charity / Sadaqah Amount",
    goldHoldings: "Gold Savings",
    goldPrice24: "24k Gold Gram Price (AED):",
    addGold: "Add Gold",
    updateGold: "Update Gold",
    extraWealthTitle: "Extra Funds / Other Income Sources",
    addWealth: "Add to Wealth",
    updateWealth: "Update Wealth",
    excelExport: "Export Monthly Statement (Excel/CSV)",
    fromDate: "From Date",
    toDate: "To Date",
    exportReport: "Download Statement",
    notesTitle: "Multiple Notes & Comparisons",
    addNote: "Add New Note",
    noteTitlePlaceholder: "Note Title...",
    noteBodyPlaceholder: "Write your note here...",
    saved: "Saved automatically ✓",
    linkGmail: "Sign in with Google",
    logout: "Sign Out",
    today: "Today",
    yesterday: "Yesterday",
    alarmsReminders: "Scheduled Alarms & Reminders",
    addAlarm: "Add Alarm / Reminder",
    alarmTitle: "Reminder Title",
    beneficiary: "Beneficiary / Person",
    reminderTime: "Time",
    reminderDate: "Date",
    frequency: "Frequency",
    freqOnce: "Once",
    freqDaily: "Daily",
    freqWeekly: "Weekly",
    freqMonthly: "Monthly",
    soundType: "Alarm Sound Type",
    soundBeep: "Beep Tone",
    soundContinuous: "Continuous Ring",
    ringAlarmNow: "🔔 ALARM ALERT!",
    dismiss: "Dismiss Alarm"
  },
  es: {
    appName: "Tharwati",
    subtitle: "Gestión Financiera Inteligente",
    dashboard: "Panel",
    transactionsTab: "Transacciones",
    currencies: "Monedas",
    accounts: "Cuentas",
    wealth: "Patrimonio",
    zakat: "Zakat y Caridad",
    remindersTab: "Alarmas y Recordatorios",
    notesTab: "Notas y Informes",
    totalLiquidity: "Liquidez Total",
    dailyExpense: "Gastos de Hoy",
    monthlyExpense: "Gastos Mensuales",
    netWealth: "Patrimonio Neto Total",
    recentTransactions: "Registro de Transacciones",
    newTransaction: "Nueva Transacción",
    expense: "Gasto",
    income: "Ingreso / Depósito",
    description: "Descripción (ej. Café, Factura, Salario...)",
    amount: "Cantidad",
    saveTransaction: "Guardar Transacción",
    updateTransaction: "Actualizar Transacción",
    smartConverter: "Conversor de Moneda Inteligente",
    liveMarketRate: "Tasa de Mercado en Vivo (Auto)",
    exchangeOfficeRate: "Tasa de Casa de Cambio (Manual ✍️)",
    amountToConvert: "Cantidad a convertir",
    convertedResult: "Resultado Convertido",
    instantRefresh: "Actualización Instantánea",
    recordAsTransaction: "Registrar como transacción en mis cuentas",
    myAccounts: "Mis Cuentas Bancarias",
    addNewAccount: "Agregar Cuenta",
    editAccount: "Editar Cuenta",
    accountName: "Nombre de Cuenta",
    bankName: "Banco",
    initialBalance: "Saldo Inicial",
    accountNumber: "Número de Cuenta",
    iban: "IBAN",
    saveAccount: "Guardar Cuenta",
    updateAccount: "Actualizar Cuenta",
    cancel: "Cancelar",
    delete: "Eliminar",
    edit: "Editar",
    zakatCalc: "Calculadora de Zakat (2.5%)",
    charityCalc: "Calculadora de Caridad",
    nisab: "Nisab de Zakat (85g 24k):",
    zakatDue: "Zakat a Pagar (2.5%):",
    charityAmount: "Cantidad de Caridad",
    goldHoldings: "Ahorros en Oro",
    goldPrice24: "Precio Gramo Oro 24k (AED):",
    addGold: "Añadir Oro",
    updateGold: "Actualizar Oro",
    extraWealthTitle: "Fondos Extra / Otras Fuentes",
    addWealth: "Añadir al Patrimonio",
    updateWealth: "Actualizar Patrimonio",
    excelExport: "Exportar Estado (Excel/CSV)",
    fromDate: "Desde Fecha",
    toDate: "Hasta Fecha",
    exportReport: "Descargar Informe",
    notesTitle: "Notas Múltiples y Comparaciones",
    addNote: "Añadir Nota",
    noteTitlePlaceholder: "Título...",
    noteBodyPlaceholder: "Escribe tu nota aquí...",
    saved: "Guardado automáticamente ✓",
    linkGmail: "Iniciar sesión con Google",
    logout: "Cerrar Sesión",
    today: "Hoy",
    yesterday: "Ayer",
    alarmsReminders: "Alarmas y Recordatorios Programados",
    addAlarm: "Añadir Alarma / Recordatorio",
    alarmTitle: "Título del Recordatorio",
    beneficiary: "Beneficiario / Persona",
    reminderTime: "Hora",
    reminderDate: "Fecha",
    frequency: "Frecuencia",
    freqOnce: "Una vez",
    freqDaily: "Diario",
    freqWeekly: "Semanal",
    freqMonthly: "Mensual",
    soundType: "Tipo de Sonido",
    soundBeep: "Tono de Pitido",
    soundContinuous: "Timbre Continuo",
    ringAlarmNow: "🔔 ¡ALERTA DE ALARMA!",
    dismiss: "Descartar Alarma"
  },
  ar: {
    appName: "ثروتي",
    subtitle: "الإدارة المالية الذكية",
    dashboard: "الرئيسية",
    transactionsTab: "المعاملات",
    currencies: "العملات",
    accounts: "الحسابات",
    wealth: "الثروة",
    zakat: "الزكاة والصدقة",
    remindersTab: "التنبيهات والمنبهات",
    notesTab: "النوتة والتقارير",
    totalLiquidity: "إجمالي السيولة",
    dailyExpense: "مصروفات اليوم",
    monthlyExpense: "مصروفات الشهر",
    netWealth: "صافي الثروة الكلي",
    recentTransactions: "سجل المعاملات",
    newTransaction: "تسجيل معاملة جديدة",
    expense: "خصم / مصروف",
    income: "إيداع / راتب",
    description: "الوصف (مثال: قهوة، فاتورة، راتب...)",
    amount: "المبلغ",
    saveTransaction: "حفظ المعاملة",
    updateTransaction: "تحديث المعاملة",
    smartConverter: "محول العملات الذكي",
    liveMarketRate: "سعر السوق الحي (تلقائي)",
    exchangeOfficeRate: "سعر مكتب صرافة (يدوي ✍️)",
    amountToConvert: "المبلغ المراد تحويله",
    convertedResult: "النتيجة المعادلة",
    instantRefresh: "تحديث فوري",
    recordAsTransaction: "تسجيل النتيجة كمعاملة في حساباتي",
    myAccounts: "حساباتي البنكية",
    addNewAccount: "إضافة حساب بنكي جديد",
    editAccount: "تعديل الحساب",
    accountName: "اسم الحساب (مثال: حساب الراتب)",
    bankName: "اسم البنك",
    initialBalance: "الرصيد الافتتاحي",
    accountNumber: "رقم الحساب",
    iban: "رقم الآيبان (IBAN)",
    saveAccount: "حفظ الحساب",
    updateAccount: "تحديث الحساب",
    cancel: "إلغاء",
    delete: "حذف",
    edit: "تعديل",
    zakatCalc: "حاسبة الزكاة (2.5%)",
    charityCalc: "حاسبة الصدقة",
    nisab: "نصاب الزكاة (85 جم عيار 24):",
    zakatDue: "مقدار الزكاة الواجبة (2.5%):",
    charityAmount: "مبلغ الصدقة المخصص",
    goldHoldings: "مدخرات الذهب",
    goldPrice24: "سعر جرام عيار 24 (AED):",
    addGold: "إضافة ذهب",
    updateGold: "تحديث الذهب",
    extraWealthTitle: "أموال إضافية / مراكز دخل أخرى",
    addWealth: "إضافة للثروة",
    updateWealth: "تحديث الثروة",
    excelExport: "استخراج كشف حساب (من تاريخ إلى تاريخ)",
    fromDate: "من تاريخ",
    toDate: "إلى تاريخ",
    exportReport: "تحميل كشف الحساب",
    notesTitle: "النوتة الداخلية المتعددة",
    addNote: "إضافة نوتة جديدة",
    noteTitlePlaceholder: "عنوان النوتة...",
    noteBodyPlaceholder: "اكتب ملاحظاتك ومقارناتك هنا...",
    saved: "يتم الحفظ تلقائياً ✓",
    linkGmail: "تسجيل الدخول بـ Google",
    logout: "تسجيل الخروج",
    today: "اليوم",
    yesterday: "أمس",
    alarmsReminders: "المنبهات والتنبيهات المجدولة",
    addAlarm: "إضافة تنبيه / منبه جديد",
    alarmTitle: "سبب التنبيه (مثل: دفع فاتورة، تحويل لشخص)",
    beneficiary: "المستفيد / الشخص",
    reminderTime: "الوقت",
    reminderDate: "التاريخ",
    frequency: "التكرار",
    freqOnce: "مرة واحدة",
    freqDaily: "كل يوم",
    freqWeekly: "كل أسبوع",
    freqMonthly: "كل شهر",
    soundType: "نوع الرنة",
    soundBeep: "رنة قصيرة (Beep)",
    soundContinuous: "رنة متواصلة",
    ringAlarmNow: "🔔 تنبيه مستحق الآن!",
    dismiss: "إيقاف المنبه"
  }
};

const BASE_CURRENCIES = [
  { code: 'USD', name: { en: 'US Dollar', es: 'Dólar USD', ar: 'دولار أمريكي' }, symbol: '$', flag: '🇺🇸', pinned: true },
  { code: 'AED', name: { en: 'UAE Dirham', es: 'Dírham AED', ar: 'درهم إماراتي' }, symbol: 'د.إ', flag: '🇦🇪', pinned: true },
  { code: 'EGP', name: { en: 'Egyptian Pound', es: 'Libra EGP', ar: 'جنيه مصري' }, symbol: 'ج.م', flag: '🇪🇬', pinned: true },
  { code: 'SAR', name: { en: 'Saudi Riyal', es: 'Riyal SAR', ar: 'ريال سعودي' }, symbol: 'ر.س', flag: '🇸🇦', pinned: false },
  { code: 'EUR', name: { en: 'Euro', es: 'Euro EUR', ar: 'يورو أوروبي' }, symbol: '€', flag: '🇪🇺', pinned: false },
  { code: 'GBP', name: { en: 'British Pound', es: 'Libra GBP', ar: 'جنيه إسترليني' }, symbol: '£', flag: '🇬🇧', pinned: false },
  { code: 'KWD', name: { en: 'Kuwaiti Dinar', es: 'Dinar KWD', ar: 'دينار كويتي' }, symbol: 'د.ك', flag: '🇰🇼', pinned: false },
  { code: 'QAR', name: { en: 'Qatari Riyal', es: 'Riyal QAR', ar: 'ريال قطري' }, symbol: 'ر.ق', flag: '🇶🇦', pinned: false },
];

const DEFAULT_RATES = { USD: 1, AED: 3.6725, EGP: 53.44, SAR: 3.75, EUR: 0.92, GBP: 0.79, KWD: 0.307, QAR: 3.64 };

export default function App() {
  const [lang, setLang] = useState(() => localStorage.getItem('tharwati_lang') || 'ar');
  const t = translations[lang] || translations.ar;

  const toggleLanguage = (newLang) => {
    setLang(newLang);
    localStorage.setItem('tharwati_lang', newLang);
  };

  const [activeTab, setActiveTab] = useState('dashboard');
  const [user, setUser] = useState(null);

  const [currencies, setCurrencies] = useState(() => {
    const saved = localStorage.getItem('tharwati_currencies');
    return saved ? JSON.parse(saved) : BASE_CURRENCIES;
  });

  const togglePinCurrency = (code) => {
    const updated = currencies.map(c => c.code === code ? { ...c, pinned: !c.pinned } : c);
    setCurrencies(updated);
    localStorage.setItem('tharwati_currencies', JSON.stringify(updated));
  };

  const sortedCurrencies = useMemo(() => {
    return [...currencies].sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));
  }, [currencies]);

  const [rates, setRates] = useState(() => {
    const saved = localStorage.getItem('tharwati_rates');
    return saved ? JSON.parse(saved) : DEFAULT_RATES;
  });
  const [lastUpdated, setLastUpdated] = useState(() => localStorage.getItem('tharwati_rates_time') || new Date().toLocaleTimeString());
  const [countdown, setCountdown] = useState(300);
  const [isRefreshingRates, setIsRefreshingRates] = useState(false);

  const [accounts, setAccounts] = useState(() => {
    const saved = localStorage.getItem('tharwati_accounts');
    return saved ? JSON.parse(saved) : [
      { id: 'acc-1', name: 'UAE Current Account', bank: 'FAB', currency: 'AED', balance: 15000, accountNumber: '1029384756', iban: 'AE070331234567890123456' },
      { id: 'acc-2', name: 'USD Savings', bank: 'Mashreq', currency: 'USD', balance: 4200, accountNumber: '9988776655', iban: 'AE450330000009988776655' },
      { id: 'acc-3', name: 'EGP Expenses', bank: 'NBE', currency: 'EGP', balance: 35000, accountNumber: '4455667788', iban: 'EG380019000500000000263180002' },
    ];
  });

  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('tharwati_transactions');
    return saved ? JSON.parse(saved) : [
      { id: 'tx-1', type: 'expense', title: 'Supermarket Groceries', amount: 240, currency: 'AED', accountId: 'acc-1', deductedAmount: 240, exchangeRateUsed: 1, date: new Date().toISOString().split('T')[0] },
      { id: 'tx-2', type: 'income', title: 'Monthly Salary', amount: 18500, currency: 'AED', accountId: 'acc-1', deductedAmount: 18500, exchangeRateUsed: 1, date: new Date().toISOString().split('T')[0] },
    ];
  });

  const [reminders, setReminders] = useState(() => {
    const saved = localStorage.getItem('tharwati_reminders');
    return saved ? JSON.parse(saved) : [
      { id: 'rem-1', title: 'Family Support Transfer', beneficiary: 'Egypt', amount: 3000, currency: 'USD', date: new Date().toISOString().split('T')[0], time: '10:00', frequency: 'monthly', soundType: 'beep', active: true }
    ];
  });

  const [goldHoldings, setGoldHoldings] = useState(() => {
    const saved = localStorage.getItem('tharwati_gold');
    return saved ? JSON.parse(saved) : [{ id: 'g-1', label: 'BTC Gold Bar 10g', weight: 10, karat: 24 }];
  });
  const [goldPrice24AED, setGoldPrice24AED] = useState(() => Number(localStorage.getItem('tharwati_gold_price_aed')) || 479.25);

  const [extraWealth, setExtraWealth] = useState(() => {
    const saved = localStorage.getItem('tharwati_extra_wealth');
    return saved ? JSON.parse(saved) : [{ id: 'ew-1', title: 'External Savings', amount: 5000, currency: 'USD' }];
  });

  const [charityInput, setCharityInput] = useState('');

  const [notesList, setNotesList] = useState(() => {
    const saved = localStorage.getItem('tharwati_notes_list');
    return saved ? JSON.parse(saved) : [
      { id: 'n-1', title: 'Exchange Office Rates Comparison', body: '- Al Ansari: 14.52 EGP\n- Direct Transfer: 14.55 EGP' },
      { id: 'n-2', title: 'Shopping Wishlist', body: '- New phone\n- Car maintenance parts' }
    ];
  });

  const [wealthCurrency, setWealthCurrency] = useState('USD');

  const [editingAccId, setEditingAccId] = useState(null);
  const [accForm, setAccForm] = useState({ name: '', bank: '', currency: 'AED', balance: '', accountNumber: '', iban: '' });

  const [editingTxId, setEditingTxId] = useState(null);
  const [txForm, setTxForm] = useState({ type: 'expense', title: '', amount: '', currency: 'USD', accountId: accounts[0]?.id || '', customRate: '', date: new Date().toISOString().split('T')[0] });

  const [editingGoldId, setEditingGoldId] = useState(null);
  const [goldForm, setGoldForm] = useState({ label: '', weight: '', karat: 24 });

  const [editingWealthId, setEditingWealthId] = useState(null);
  const [extraForm, setExtraForm] = useState({ title: '', amount: '', currency: 'USD' });

  const [editingNoteId, setEditingNoteId] = useState(null);
  const [noteForm, setNoteForm] = useState({ title: '', body: '' });

  const [editingAlarmId, setEditingAlarmId] = useState(null);
  const [alarmForm, setAlarmForm] = useState({ title: '', beneficiary: '', amount: '', currency: 'USD', date: new Date().toISOString().split('T')[0], time: '12:00', frequency: 'once', soundType: 'beep' });

  const [statementFrom, setStatementFrom] = useState(() => new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0]);
  const [statementTo, setStatementTo] = useState(() => new Date().toISOString().split('T')[0]);

  const [convAmount, setConvAmount] = useState('100');
  const [convFrom, setConvFrom] = useState('USD');
  const [convTo, setConvTo] = useState('EGP');
  const [convMode, setConvMode] = useState('auto');
  const [convManualRate, setConvManualRate] = useState('');
  const [convAccountTarget, setConvAccountTarget] = useState(accounts[0]?.id || '');

  const [ringingAlarm, setRingingAlarm] = useState(null);
  const audioContextRef = useRef(null);

  const playAlarmSound = (soundType) => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const playBeep = (timeOffset, freq) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(0.2, ctx.currentTime + timeOffset);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + timeOffset + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + timeOffset);
        osc.stop(ctx.currentTime + timeOffset + 0.3);
      };

      playBeep(0, 800);
      playBeep(0.4, 1000);
      if (soundType === 'continuous') {
        playBeep(0.8, 800);
        playBeep(1.2, 1000);
      }
    } catch (e) {
      console.warn("Audio Context error:", e);
    }
  };

  useEffect(() => {
    const alarmInterval = setInterval(() => {
      const now = new Date();
      const currDate = now.toISOString().split('T')[0];
      const currTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

      reminders.forEach(rem => {
        if (rem.active && rem.date === currDate && rem.time === currTime) {
          setRingingAlarm(rem);
          playAlarmSound(rem.soundType);
        }
      });
    }, 30000);
    return () => clearInterval(alarmInterval);
  }, [reminders]);

  useEffect(() => {
    localStorage.setItem('tharwati_accounts', JSON.stringify(accounts));
    localStorage.setItem('tharwati_transactions', JSON.stringify(transactions));
    localStorage.setItem('tharwati_reminders', JSON.stringify(reminders));
    localStorage.setItem('tharwati_gold', JSON.stringify(goldHoldings));
    localStorage.setItem('tharwati_gold_price_aed', String(goldPrice24AED));
    localStorage.setItem('tharwati_extra_wealth', JSON.stringify(extraWealth));
    localStorage.setItem('tharwati_notes_list', JSON.stringify(notesList));

    if (user && db) {
      setDoc(doc(db, 'users', user.uid), {
        accounts, transactions, reminders, goldHoldings, goldPrice24AED, extraWealth, notesList, updatedAt: new Date().toISOString()
      }, { merge: true }).catch(err => console.error(err));
    }
  }, [accounts, transactions, reminders, goldHoldings, goldPrice24AED, extraWealth, notesList, user]);

  useEffect(() => {
    if (!auth) return;
    const unsub = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser && db) {
        onSnapshot(doc(db, 'users', currentUser.uid), (snap) => {
          if (snap.exists()) {
            const data = snap.data();
            if (data.accounts) setAccounts(data.accounts);
            if (data.transactions) setTransactions(data.transactions);
            if (data.reminders) setReminders(data.reminders);
            if (data.goldHoldings) setGoldHoldings(data.goldHoldings);
            if (data.goldPrice24AED) setGoldPrice24AED(data.goldPrice24AED);
            if (data.extraWealth) setExtraWealth(data.extraWealth);
            if (data.notesList) setNotesList(data.notesList);
          }
        });
      }
    });
    return () => unsub();
  }, []);

  const fetchRates = async () => {
    setIsRefreshingRates(true);
    try {
      const res = await fetch('https://open.er-api.com/v6/latest/USD');
      const data = await res.json();
      if (data && data.rates) {
        const updated = { ...DEFAULT_RATES };
        BASE_CURRENCIES.forEach(c => { if (data.rates[c.code]) updated[c.code] = data.rates[c.code]; });
        setRates(updated);
        localStorage.setItem('tharwati_rates', JSON.stringify(updated));
        const now = new Date().toLocaleTimeString();
        setLastUpdated(now);
        localStorage.setItem('tharwati_rates_time', now);
        setCountdown(300);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsRefreshingRates(false);
    }
  };

  useEffect(() => {
    fetchRates();
    const timer = setInterval(() => {
      setCountdown(prev => (prev <= 1 ? (fetchRates(), 300) : prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const convertCurrency = (amount, fromCode, toCode, customRate = null) => {
    if (!amount || isNaN(amount)) return 0;
    if (fromCode === toCode) return Number(amount);
    if (customRate && Number(customRate) > 0) return Number(amount) * Number(customRate);
    const inUSD = Number(amount) / (rates[fromCode] || 1);
    return inUSD * (rates[toCode] || 1);
  };

  const getDirectRate = (fromCode, toCode) => (fromCode === toCode ? 1 : (rates[toCode] || 1) / (rates[fromCode] || 1));

  const selectedTxAccount = accounts.find(a => a.id === txForm.accountId) || accounts[0];
  useEffect(() => {
    if (selectedTxAccount && txForm.currency !== selectedTxAccount.currency) {
      setTxForm(prev => ({ ...prev, customRate: getDirectRate(txForm.currency, selectedTxAccount.currency).toFixed(6) }));
    } else {
      setTxForm(prev => ({ ...prev, customRate: '1' }));
    }
  }, [txForm.currency, txForm.accountId, rates]);

  const handleSaveTransaction = (e) => {
    e.preventDefault();
    if (!txForm.title || !txForm.amount || !selectedTxAccount) return;
    const rawAmount = parseFloat(txForm.amount);
    const rateUsed = txForm.currency === selectedTxAccount.currency ? 1 : (parseFloat(txForm.customRate) || getDirectRate(txForm.currency, selectedTxAccount.currency));
    const impact = rawAmount * rateUsed;

    if (editingTxId) {
      const oldTx = transactions.find(t => t.id === editingTxId);
      setAccounts(accounts.map(acc => {
        if (acc.id === oldTx.accountId) {
          const revDelta = oldTx.type === 'expense' ? oldTx.deductedAmount : -oldTx.deductedAmount;
          return { ...acc, balance: Number((acc.balance + revDelta).toFixed(2)) };
        }
        return acc;
      }));

      setTransactions(transactions.map(t => t.id === editingTxId ? {
        ...t, type: txForm.type, title: txForm.title, amount: rawAmount, currency: txForm.currency,
        accountId: selectedTxAccount.id, deductedAmount: Number(impact.toFixed(2)), exchangeRateUsed: rateUsed, date: txForm.date
      } : t));

      setAccounts(prevAccs => prevAccs.map(acc => {
        if (acc.id === selectedTxAccount.id) {
          const delta = txForm.type === 'expense' ? -impact : impact;
          return { ...acc, balance: Number((acc.balance + delta).toFixed(2)) };
        }
        return acc;
      }));

      setEditingTxId(null);
    } else {
      const newTx = {
        id: 'tx-' + Date.now(),
        type: txForm.type,
        title: txForm.title,
        amount: rawAmount,
        currency: txForm.currency,
        accountId: selectedTxAccount.id,
        deductedAmount: Number(impact.toFixed(2)),
        exchangeRateUsed: rateUsed,
        date: txForm.date
      };
      setTransactions([newTx, ...transactions]);
      setAccounts(accounts.map(acc => acc.id === selectedTxAccount.id ? { ...acc, balance: Number((acc.balance + (txForm.type === 'expense' ? -impact : impact)).toFixed(2)) } : acc));
    }
    setTxForm({ type: 'expense', title: '', amount: '', currency: wealthCurrency, accountId: accounts[0]?.id || '', customRate: '', date: new Date().toISOString().split('T')[0] });
  };

  const handleDeleteTransaction = (txId) => {
    const tx = transactions.find(t => t.id === txId);
    if (!tx) return;
    setTransactions(transactions.filter(t => t.id !== txId));
    setAccounts(accounts.map(acc => {
      if (acc.id === tx.accountId) {
        const reverseDelta = tx.type === 'expense' ? tx.deductedAmount : -tx.deductedAmount;
        return { ...acc, balance: Number((acc.balance + reverseDelta).toFixed(2)) };
      }
      return acc;
    }));
  };

  const effectiveConvRate = convMode === 'manual' && parseFloat(convManualRate) > 0 ? parseFloat(convManualRate) : getDirectRate(convFrom, convTo);
  const convertedResult = (parseFloat(convAmount) || 0) * effectiveConvRate;

  const handleRecordConversionAsTx = () => {
    const targetAcc = accounts.find(a => a.id === convAccountTarget) || accounts[0];
    if (!targetAcc || !convAmount) return;
    const rawAmt = parseFloat(convAmount);
    const rateToAccount = convFrom === targetAcc.currency ? 1 : (convTo === targetAcc.currency ? effectiveConvRate : getDirectRate(convFrom, targetAcc.currency));
    const impact = Number((rawAmt * rateToAccount).toFixed(2));

    const newTx = {
      id: 'tx-' + Date.now(),
      type: 'expense',
      title: `Exchange / Transfer (${rawAmt} ${convFrom} → ${convertedResult.toFixed(2)} ${convTo})`,
      amount: rawAmt,
      currency: convFrom,
      accountId: targetAcc.id,
      deductedAmount: impact,
      exchangeRateUsed: rateToAccount,
      date: new Date().toISOString().split('T')[0]
    };
    setTransactions([newTx, ...transactions]);
    setAccounts(accounts.map(a => a.id === targetAcc.id ? { ...a, balance: Number((a.balance - impact).toFixed(2)) } : a));
    setActiveTab('dashboard');
  };

  const groupedTransactions = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const yestDate = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const groups = { today: [], yesterday: [], others: {} };

    transactions.forEach(tx => {
      if (tx.date === today) groups.today.push(tx);
      else if (tx.date === yestDate) groups.yesterday.push(tx);
      else {
        if (!groups.others[tx.date]) groups.others[tx.date] = [];
        groups.others[tx.date].push(tx);
      }
    });
    return groups;
  }, [transactions]);

  const formatDayName = (dateStr) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(lang === 'ar' ? 'ar-EG' : (lang === 'es' ? 'es-ES' : 'en-US'), { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthPrefix = todayStr.slice(0, 7);

  const stats = useMemo(() => {
    let dailyExpense = 0, monthlyExpense = 0;
    transactions.forEach(tx => {
      const converted = convertCurrency(tx.amount, tx.currency, wealthCurrency);
      if (tx.type === 'expense') {
        if (tx.date === todayStr) dailyExpense += converted;
        if (tx.date.startsWith(currentMonthPrefix)) monthlyExpense += converted;
      }
    });
    const accountsTotal = accounts.reduce((sum, acc) => sum + convertCurrency(acc.balance, acc.currency, wealthCurrency), 0);
    const goldTotalAED = goldHoldings.reduce((sum, g) => sum + (Number(g.weight) * (g.karat === 24 ? 1 : g.karat / 24) * goldPrice24AED), 0);
    const goldTotal = convertCurrency(goldTotalAED, 'AED', wealthCurrency);
    const extraTotal = extraWealth.reduce((sum, item) => sum + convertCurrency(item.amount, item.currency, wealthCurrency), 0);
    const netWealth = accountsTotal + goldTotal + extraTotal;
    const nisabSelected = convertCurrency(85 * goldPrice24AED, 'AED', wealthCurrency);
    const isZakatDue = netWealth >= nisabSelected;
    const zakatAmount = isZakatDue ? netWealth * 0.025 : 0;
    return { dailyExpense, monthlyExpense, accountsTotal, goldTotal, extraTotal, netWealth, nisabSelected, isZakatDue, zakatAmount };
  }, [transactions, accounts, goldHoldings, goldPrice24AED, extraWealth, wealthCurrency, rates]);

  const exportFilteredStatement = () => {
    const filtered = transactions.filter(tx => tx.date >= statementFrom && tx.date <= statementTo);
    const headers = ['Date', 'Type', 'Description', 'Original Amount', 'Currency', 'Account', 'Impact', 'Account Currency', 'Rate'];
    const rows = filtered.map(tx => {
      const acc = accounts.find(a => a.id === tx.accountId);
      return [tx.date, tx.type, `"${tx.title}"`, tx.amount, tx.currency, `"${acc?.name}"`, tx.deductedAmount, acc?.currency, tx.exchangeRateUsed].join(',');
    });
    const blob = new Blob(['﻿' + [headers.join(','), ...rows].join('\n')], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `Statement_${statementFrom}_to_${statementTo}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGoogleLogin = async () => {
    if (!auth || !googleProvider) {
      alert('Cloud sync requires Firebase credentials. Running in private local-first mode.');
      return;
    }
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (e) {
      console.error(e);
    }
  };

  const currencyName = (c) => typeof c.name === 'object' ? (c.name[lang] || c.name.en) : c.name;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-24" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      
      {ringingAlarm && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-pulse">
          <div className="bg-slate-900 border-2 border-amber-500 rounded-3xl p-6 max-w-md w-full text-center space-y-4 shadow-2xl">
            <Bell className="w-16 h-16 text-amber-400 mx-auto animate-bounce" />
            <h2 className="text-xl font-extrabold text-amber-300">{t.ringAlarmNow}</h2>
            <div className="bg-slate-800 p-4 rounded-xl text-right">
              <p className="text-sm font-bold text-white">📌 {ringingAlarm.title}</p>
              <p className="text-xs text-slate-300 mt-1">👤 {ringingAlarm.beneficiary} • 💰 {ringingAlarm.amount} {ringingAlarm.currency}</p>
              <p className="text-xs text-slate-400 mt-1">⏰ {ringingAlarm.date} at {ringingAlarm.time}</p>
            </div>
            <button onClick={() => { setRingingAlarm(null); }} className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-3 rounded-xl transition">
              {t.dismiss}
            </button>
          </div>
        </div>
      )}

      <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Wallet className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-white leading-tight">{t.appName}</h1>
              <p className="text-xs text-slate-400">{t.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-slate-800 p-0.5 rounded-lg text-xs">
              <button onClick={() => toggleLanguage('en')} className={`px-2 py-1 rounded ${lang === 'en' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400'}`}>EN</button>
              <button onClick={() => toggleLanguage('es')} className={`px-2 py-1 rounded ${lang === 'es' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400'}`}>ES</button>
              <button onClick={() => toggleLanguage('ar')} className={`px-2 py-1 rounded ${lang === 'ar' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400'}`}>AR</button>
            </div>

            {user ? (
              <button onClick={() => signOut(auth)} className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-xs px-2.5 py-1.5 rounded-lg border border-slate-700">
                <Cloud className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">{user.displayName?.split(' ')[0]}</span>
                <LogOut className="w-3.5 h-3.5 text-slate-400" />
              </button>
            ) : (
              <button onClick={handleGoogleLogin} className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-2.5 py-1.5 rounded-lg transition">
                <Cloud className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t.linkGmail}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4 space-y-5">
        
        {activeTab === 'dashboard' && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5">
                <span className="text-xs text-slate-400 block">{t.totalLiquidity}</span>
                <span className="text-lg font-bold text-white mt-1 block">{stats.accountsTotal.toLocaleString('en-US', {maximumFractionDigits:1})} <span className="text-xs text-emerald-400">{wealthCurrency}</span></span>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5">
                <span className="text-xs text-slate-400 block">{t.dailyExpense}</span>
                <span className="text-lg font-bold text-rose-400 mt-1 block">{stats.dailyExpense.toLocaleString('en-US', {maximumFractionDigits:1})} <span className="text-xs">{wealthCurrency}</span></span>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5">
                <span className="text-xs text-slate-400 block">{t.monthlyExpense}</span>
                <span className="text-lg font-bold text-amber-400 mt-1 block">{stats.monthlyExpense.toLocaleString('en-US', {maximumFractionDigits:1})} <span className="text-xs">{wealthCurrency}</span></span>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5">
                <span className="text-xs text-slate-400 block">{t.netWealth}</span>
                <span className="text-lg font-bold text-emerald-400 mt-1 block">{stats.netWealth.toLocaleString('en-US', {maximumFractionDigits:1})} <span className="text-xs">{wealthCurrency}</span></span>
              </div>
            </div>

            <form onSubmit={handleSaveTransaction} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-sm text-white flex items-center gap-2">
                  <Plus className="w-4 h-4 text-emerald-400" />
                  {editingTxId ? t.updateTransaction : t.newTransaction}
                </h2>
                <div className="flex bg-slate-800 p-0.5 rounded-lg text-xs">
                  <button type="button" onClick={() => setTxForm({ ...txForm, type: 'expense' })} className={`px-3 py-1 rounded-md font-medium ${txForm.type === 'expense' ? 'bg-rose-500 text-white' : 'text-slate-400'}`}>{t.expense}</button>
                  <button type="button" onClick={() => setTxForm({ ...txForm, type: 'income' })} className={`px-3 py-1 rounded-md font-medium ${txForm.type === 'income' ? 'bg-emerald-500 text-white' : 'text-slate-400'}`}>{t.income}</button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input type="text" placeholder={t.description} value={txForm.title} onChange={e => setTxForm({ ...txForm, title: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" required />
                <div className="flex gap-2">
                  <input type="number" step="any" placeholder={t.amount} value={txForm.amount} onChange={e => setTxForm({ ...txForm, amount: e.target.value })} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" required />
                  <select value={txForm.currency} onChange={e => setTxForm({ ...txForm, currency: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-sm text-white">
                    {sortedCurrencies.map(c => <option key={c.code} value={c.code}>{c.code} {c.pinned ? '⭐' : ''}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Account:</label>
                  <select value={txForm.accountId} onChange={e => setTxForm({ ...txForm, accountId: e.target.value })} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white">
                    {accounts.map(acc => <option key={acc.id} value={acc.id}>{acc.name} ({acc.currency})</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Date:</label>
                  <input type="date" value={txForm.date} onChange={e => setTxForm({ ...txForm, date: e.target.value })} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" />
                </div>
              </div>

              <div className="flex gap-2">
                <button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 rounded-xl text-sm transition">{editingTxId ? t.updateTransaction : t.saveTransaction}</button>
                {editingTxId && (
                  <button type="button" onClick={() => { setEditingTxId(null); setTxForm({ type: 'expense', title: '', amount: '', currency: wealthCurrency, accountId: accounts[0]?.id || '', customRate: '', date: new Date().toISOString().split('T')[0] }); }} className="bg-slate-800 px-4 py-2.5 rounded-xl text-sm text-slate-300">{t.cancel}</button>
                )}
              </div>
            </form>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
              <h3 className="font-bold text-sm text-white">{t.recentTransactions}</h3>
              {transactions.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-4">No transactions yet.</p>
              ) : (
                <div className="space-y-4">
                  {groupedTransactions.today.length > 0 && (
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg inline-block">
                        {t.today} ({formatDayName(todayStr)})
                      </span>
                      {groupedTransactions.today.map(tx => renderTxItem(tx, setEditingTxId, setTxForm, handleDeleteTransaction, t))}
                    </div>
                  )}

                  {groupedTransactions.yesterday.length > 0 && (
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg inline-block">
                        {t.yesterday} ({formatDayName(new Date(Date.now() - 86400000).toISOString().split('T')[0])})
                      </span>
                      {groupedTransactions.yesterday.map(tx => renderTxItem(tx, setEditingTxId, setTxForm, handleDeleteTransaction, t))}
                    </div>
                  )}

                  {Object.keys(groupedTransactions.others).map(dateKey => (
                    <div key={dateKey} className="space-y-2">
                      <span className="text-xs font-bold text-slate-300 bg-slate-800 px-2.5 py-1 rounded-lg inline-block">
                        {formatDayName(dateKey)}
                      </span>
                      {groupedTransactions.others[dateKey].map(tx => renderTxItem(tx, setEditingTxId, setTxForm, handleDeleteTransaction, t))}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === 'transactionsTab' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <Wallet className="w-5 h-5 text-emerald-400" />
                {t.recentTransactions} (Full Log)
              </h2>
              <div className="space-y-3">
                {transactions.map(tx => renderTxItem(tx, setEditingTxId, setTxForm, handleDeleteTransaction, t, () => setActiveTab('dashboard')))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'currencies' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-bold text-base text-white flex items-center gap-2">
                    <ArrowLeftRight className="w-4 h-4 text-emerald-400" />
                    {t.smartConverter}
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">Last updated: {lastUpdated}</p>
                </div>
                <button onClick={fetchRates} disabled={isRefreshingRates} className="flex items-center gap-1.5 bg-slate-800 text-xs px-3 py-2 rounded-xl border border-slate-700 text-emerald-400">
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingRates ? 'animate-spin' : ''}`} />
                  <span>{t.instantRefresh}</span>
                </button>
              </div>

              <div className="flex bg-slate-800 p-1 rounded-xl text-xs">
                <button onClick={() => setConvMode('auto')} className={`flex-1 py-1.5 rounded-lg font-medium transition ${convMode === 'auto' ? 'bg-emerald-600 text-white' : 'text-slate-400'}`}>
                  {t.liveMarketRate}
                </button>
                <button onClick={() => setConvMode('manual')} className={`flex-1 py-1.5 rounded-lg font-medium transition ${convMode === 'manual' ? 'bg-amber-600 text-white' : 'text-slate-400'}`}>
                  {t.exchangeOfficeRate}
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                <div className="space-y-1">
                  <label className="text-xs text-slate-400">{t.amountToConvert}</label>
                  <div className="flex gap-2">
                    <input type="number" value={convAmount} onChange={e => setConvAmount(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-bold" />
                    <select value={convFrom} onChange={e => setConvFrom(e.target.value)} className="bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-sm text-white">
                      {sortedCurrencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                    </select>
                  </div>
                </div>
                <div className="flex justify-center pt-4">
                  <button onClick={() => { setConvFrom(convTo); setConvTo(convFrom); }} className="p-2.5 rounded-full bg-slate-800 text-emerald-400">
                    <ArrowLeftRight className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-slate-400">{t.convertedResult}</label>
                  <div className="flex gap-2">
                    <div className="w-full bg-slate-950 border border-emerald-500/40 rounded-xl px-3 py-2 text-sm text-emerald-400 font-bold flex items-center">
                      {convertedResult.toLocaleString('en-US', {maximumFractionDigits:3})}
                    </div>
                    <select value={convTo} onChange={e => setConvTo(e.target.value)} className="bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-sm text-white">
                      {sortedCurrencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              {convMode === 'manual' && (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 flex items-center gap-3">
                  <span className="text-xs text-amber-300 shrink-0">Custom Office Rate (1 {convFrom} =):</span>
                  <input type="number" step="any" placeholder={getDirectRate(convFrom, convTo).toFixed(4)} value={convManualRate} onChange={e => setConvManualRate(e.target.value)} className="w-full bg-slate-900 border border-amber-500/40 rounded-lg px-3 py-1.5 text-sm text-amber-300 font-mono" />
                  <span className="text-xs text-amber-300">{convTo}</span>
                </div>
              )}

              <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row gap-2">
                <select value={convAccountTarget} onChange={e => setConvAccountTarget(e.target.value)} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white flex-1">
                  {accounts.map(a => <option key={a.id} value={a.id}>Deduct from: {a.name} ({a.currency})</option>)}
                </select>
                <button onClick={handleRecordConversionAsTx} className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-4 py-2 rounded-xl transition">
                  {t.recordAsTransaction}
                </button>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="font-bold text-sm text-white">Currencies & Preferred Pinning (⭐ Pin USD, AED, EGP or any to top)</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {currencies.map(c => (
                  <div key={c.code} className="flex items-center justify-between bg-slate-800/50 border border-slate-800 rounded-xl p-3">
                    <div className="flex items-center gap-2.5">
                      <span className="text-xl">{c.flag || '💱'}</span>
                      <div>
                        <h4 className="text-sm font-semibold text-white">{currencyName(c)}</h4>
                        <span className="text-xs text-slate-400">{c.code}</span>
                      </div>
                    </div>
                    <button onClick={() => togglePinCurrency(c.code)} className={`text-xs px-3 py-1.5 rounded-lg font-medium transition ${c.pinned ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-700 text-slate-300'}`}>
                      {c.pinned ? '⭐ Pinned' : 'Pin to top'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'accounts' && (
          <div className="space-y-5">
            <div className="space-y-3">
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <Landmark className="w-4 h-4 text-emerald-400" />
                {t.myAccounts}
              </h2>
              {accounts.map(acc => (
                <div key={acc.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-xs bg-emerald-500/15 text-emerald-400 px-2 py-0.5 rounded-md font-medium">{acc.bank}</span>
                      <h3 className="font-bold text-base text-white mt-1">{acc.name}</h3>
                    </div>
                    <div className="text-left">
                      <span className="text-xl font-bold text-white">{acc.balance.toLocaleString('en-US')}</span>
                      <span className="text-xs text-emerald-400 font-bold block">{acc.currency}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                    <span className="text-slate-400 font-mono">IBAN: {acc.iban || '-'}</span>
                    <div className="flex gap-2">
                      <button onClick={() => { setEditingAccId(acc.id); setAccForm(acc); }} className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded-lg">
                        <Edit2 className="w-3.5 h-3.5 text-emerald-400" /> {t.edit}
                      </button>
                      <button onClick={() => setAccounts(accounts.filter(a => a.id !== acc.id))} className="flex items-center gap-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 px-3 py-1 rounded-lg">
                        <Trash2 className="w-3.5 h-3.5" /> {t.delete}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={(e) => {
              e.preventDefault();
              if (!accForm.name || !accForm.bank) return;
              if (editingAccId) {
                setAccounts(accounts.map(a => a.id === editingAccId ? { ...accForm, id: editingAccId, balance: parseFloat(accForm.balance) || 0 } : a));
                setEditingAccId(null);
              } else {
                setAccounts([...accounts, { ...accForm, id: 'acc-' + Date.now(), balance: parseFloat(accForm.balance) || 0 }]);
              }
              setAccForm({ name: '', bank: '', currency: 'AED', balance: '', accountNumber: '', iban: '' });
            }} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="font-bold text-sm text-white">{editingAccId ? t.editAccount : t.addNewAccount}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input type="text" placeholder={t.accountName} value={accForm.name} onChange={e => setAccForm({ ...accForm, name: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" required />
                <input type="text" placeholder={t.bankName} value={accForm.bank} onChange={e => setAccForm({ ...accForm, bank: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" required />
                <select value={accForm.currency} onChange={e => setAccForm({ ...accForm, currency: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white">
                  {sortedCurrencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                </select>
                <input type="number" step="any" placeholder={t.initialBalance} value={accForm.balance} onChange={e => setAccForm({ ...accForm, balance: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" />
                <input type="text" placeholder={t.accountNumber} value={accForm.accountNumber} onChange={e => setAccForm({ ...accForm, accountNumber: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono" />
                <input type="text" placeholder={t.iban} value={accForm.iban} onChange={e => setAccForm({ ...accForm, iban: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono" />
              </div>
              <div className="flex gap-2">
                <button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2 rounded-xl text-sm">{editingAccId ? t.updateAccount : t.saveAccount}</button>
                {editingAccId && (
                  <button type="button" onClick={() => { setEditingAccId(null); setAccForm({ name: '', bank: '', currency: 'AED', balance: '', accountNumber: '', iban: '' }); }} className="bg-slate-800 px-4 rounded-xl text-sm text-slate-300">{t.cancel}</button>
                )}
              </div>
            </form>
          </div>
        )}

        {activeTab === 'wealth' && (
          <div className="space-y-5">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
              <span className="text-sm font-semibold text-white">Unified Wealth Currency:</span>
              <select value={wealthCurrency} onChange={e => setWealthCurrency(e.target.value)} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-emerald-400 font-bold">
                {sortedCurrencies.map(c => <option key={c.code} value={c.code}>{c.code} {c.pinned ? '⭐' : ''}</option>)}
              </select>
            </div>

            <div className="bg-gradient-to-br from-emerald-900/40 to-slate-900 border border-emerald-500/30 rounded-2xl p-5 space-y-3">
              <span className="text-xs text-emerald-300 font-medium">{t.netWealth}</span>
              <div className="text-3xl font-extrabold text-white">
                {stats.netWealth.toLocaleString('en-US', { maximumFractionDigits: 2 })} <span className="text-base text-emerald-400">{wealthCurrency}</span>
              </div>
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-xs">
                <div>
                  <span className="text-slate-400 block">Bank Accounts</span>
                  <strong className="text-white">{stats.accountsTotal.toLocaleString('en-US', { maximumFractionDigits: 0 })} {wealthCurrency}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">Gold Value</span>
                  <strong className="text-amber-400">{stats.goldTotal.toLocaleString('en-US', { maximumFractionDigits: 0 })} {wealthCurrency}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">Extra Wealth</span>
                  <strong className="text-sky-400">{stats.extraTotal.toLocaleString('en-US', { maximumFractionDigits: 0 })} {wealthCurrency}</strong>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-white flex items-center gap-2"><Coins className="w-4 h-4 text-amber-400" />{t.goldHoldings}</h3>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400">{t.goldPrice24}</span>
                  <input type="number" step="any" value={goldPrice24AED} onChange={e => setGoldPrice24AED(parseFloat(e.target.value) || 0)} className="w-24 bg-slate-800 border border-amber-500/40 rounded-lg px-2 py-1 text-amber-400 font-mono font-bold" />
                </div>
              </div>
              <div className="space-y-2">
                {goldHoldings.map(g => {
                  const val = convertCurrency(g.weight * (g.karat === 24 ? 1 : g.karat / 24) * goldPrice24AED, 'AED', wealthCurrency);
                  return (
                    <div key={g.id} className="flex items-center justify-between bg-slate-800/50 border border-slate-800 rounded-xl p-3">
                      <div>
                        <h4 className="text-sm font-medium text-white">{g.label}</h4>
                        <p className="text-xs text-slate-400">{g.weight}g • {g.karat}k</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-bold text-amber-400">{val.toLocaleString('en-US', {maximumFractionDigits:1})} {wealthCurrency}</span>
                        <div className="flex gap-1.5">
                          <button onClick={() => { setEditingGoldId(g.id); setGoldForm(g); }} className="p-1 bg-slate-800 text-emerald-400 rounded-lg"><Edit2 className="w-3.5 h-3.5" /></button>
                          <button onClick={() => setGoldHoldings(goldHoldings.filter(i => i.id !== g.id))} className="p-1 bg-slate-800 text-rose-400 rounded-lg"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <form onSubmit={(e) => {
                e.preventDefault();
                if (!goldForm.weight) return;
                if (editingGoldId) {
                  setGoldHoldings(goldHoldings.map(g => g.id === editingGoldId ? { ...goldForm, id: editingGoldId, weight: parseFloat(goldForm.weight), karat: Number(goldForm.karat) } : g));
                  setEditingGoldId(null);
                } else {
                  setGoldHoldings([...goldHoldings, { id: 'g-' + Date.now(), label: goldForm.label || `Gold ${goldForm.karat}k`, weight: parseFloat(goldForm.weight), karat: Number(goldForm.karat) }]);
                }
                setGoldForm({ label: '', weight: '', karat: 24 });
              }} className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800">
                <input type="text" placeholder="Description" value={goldForm.label} onChange={e => setGoldForm({ ...goldForm, label: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white" />
                <input type="number" step="any" placeholder="Weight (g)" value={goldForm.weight} onChange={e => setGoldForm({ ...goldForm, weight: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white" required />
                <select value={goldForm.karat} onChange={e => setGoldForm({ ...goldForm, karat: Number(e.target.value) })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white">
                  <option value={24}>24k</option>
                  <option value={21}>21k</option>
                  <option value={18}>18k</option>
                </select>
                <div className="flex gap-1">
                  <button type="submit" className="flex-1 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-xl py-1.5">{editingGoldId ? t.updateGold : t.addGold}</button>
                  {editingGoldId && <button type="button" onClick={() => setEditingGoldId(null)} className="bg-slate-800 px-2 rounded-xl text-xs">✕</button>}
                </div>
              </form>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="font-bold text-sm text-white">{t.extraWealthTitle}</h3>
              <div className="space-y-2">
                {extraWealth.map(ew => (
                  <div key={ew.id} className="flex items-center justify-between bg-slate-800/50 border border-slate-800 rounded-xl p-3">
                    <span className="text-sm text-white">{ew.title}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-sky-400">{ew.amount.toLocaleString()} {ew.currency}</span>
                      <div className="flex gap-1.5">
                        <button onClick={() => { setEditingWealthId(ew.id); setExtraForm(ew); }} className="p-1 bg-slate-800 text-emerald-400 rounded-lg"><Edit2 className="w-3.5 h-3.5" /></button>
                        <button onClick={() => setExtraWealth(extraWealth.filter(i => i.id !== ew.id))} className="p-1 bg-slate-800 text-rose-400 rounded-lg"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={(e) => {
                e.preventDefault();
                if (!extraForm.title || !extraForm.amount) return;
                if (editingWealthId) {
                  setExtraWealth(extraWealth.map(ew => ew.id === editingWealthId ? { ...extraForm, id: editingWealthId, amount: parseFloat(extraForm.amount) } : ew));
                  setEditingWealthId(null);
                } else {
                  setExtraWealth([...extraWealth, { id: 'ew-' + Date.now(), title: extraForm.title, amount: parseFloat(extraForm.amount), currency: extraForm.currency }]);
                }
                setExtraForm({ title: '', amount: '', currency: 'USD' });
              }} className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-800">
                <input type="text" placeholder="Source" value={extraForm.title} onChange={e => setExtraForm({ ...extraForm, title: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white" required />
                <div className="flex gap-1">
                  <input type="number" step="any" placeholder="Amount" value={extraForm.amount} onChange={e => setExtraForm({ ...extraForm, amount: e.target.value })} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white" required />
                  <select value={extraForm.currency} onChange={e => setExtraForm({ ...extraForm, currency: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-2 py-1.5 text-xs text-white">
                    {sortedCurrencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                  </select>
                </div>
                <div className="flex gap-1">
                  <button type="submit" className="flex-1 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold rounded-xl py-1.5">{editingWealthId ? t.updateWealth : t.addWealth}</button>
                  {editingWealthId && <button type="button" onClick={() => setEditingWealthId(null)} className="bg-slate-800 px-2 rounded-xl text-xs">✕</button>}
                </div>
              </form>
            </div>
          </div>
        )}

        {activeTab === 'zakat' && (
          <div className="space-y-5">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
              <span className="text-sm font-semibold text-white">Calculation Currency:</span>
              <select value={wealthCurrency} onChange={e => setWealthCurrency(e.target.value)} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-emerald-400 font-bold">
                {sortedCurrencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
              </select>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                {t.zakatCalc}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-800/50 p-4 rounded-xl">
                <div>
                  <span className="text-slate-400 block mb-1">{t.nisab}</span>
                  <strong className="text-white text-base">{stats.nisabSelected.toLocaleString('en-US', {maximumFractionDigits:0})} {wealthCurrency}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">{t.zakatDue}</span>
                  <strong className="text-emerald-400 text-base">
                    {stats.isZakatDue ? `${stats.zakatAmount.toLocaleString('en-US', {maximumFractionDigits:2})} ${wealthCurrency}` : 'Net wealth is below Nisab threshold.'}
                  </strong>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <HeartHandshake className="w-5 h-5 text-sky-400" />
                {t.charityCalc}
              </h3>
              <div className="space-y-3 bg-slate-800/50 p-4 rounded-xl">
                <label className="text-xs text-slate-400 block">{t.charityAmount}</label>
                <div className="flex gap-2">
                  <input type="number" step="any" placeholder="0.00" value={charityInput} onChange={e => setCharityInput(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" />
                  <span className="bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-sm text-sky-400 font-bold flex items-center">{wealthCurrency}</span>
                </div>
                {charityInput && (
                  <p className="text-xs text-slate-300">
                    Calculated Sadaqah/Charity: <strong className="text-sky-400">{Number(charityInput).toLocaleString()} {wealthCurrency}</strong>
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'remindersTab' && (
          <div className="space-y-5">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <Bell className="w-5 h-5 text-amber-400" />
                {t.alarmsReminders}
              </h2>
              <div className="space-y-2">
                {reminders.map(rem => (
                  <div key={rem.id} className="flex items-center justify-between bg-slate-800/50 border border-slate-800 rounded-xl p-3.5">
                    <div>
                      <h4 className="text-sm font-semibold text-white">📌 {rem.title}</h4>
                      <p className="text-xs text-slate-400">👤 {rem.beneficiary} • 💰 {rem.amount} {rem.currency} • ⏰ {rem.date} at {rem.time} ({rem.frequency})</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => setReminders(reminders.map(r => r.id === rem.id ? { ...r, active: !r.active } : r))} className={`text-xs px-2.5 py-1 rounded-lg ${rem.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700 text-slate-400'}`}>
                        {rem.active ? 'Active ✓' : 'Muted'}
                      </button>
                      <button onClick={() => { setEditingAlarmId(rem.id); setAlarmForm(rem); }} className="p-1.5 bg-slate-800 text-emerald-400 rounded-lg"><Edit2 className="w-3.5 h-3.5" /></button>
                      <button onClick={() => setReminders(reminders.filter(r => r.id !== rem.id))} className="p-1.5 bg-slate-800 text-rose-400 rounded-lg"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={(e) => {
                e.preventDefault();
                if (!alarmForm.title || !alarmForm.amount) return;
                if (editingAlarmId) {
                  setReminders(reminders.map(r => r.id === editingAlarmId ? { ...alarmForm, id: editingAlarmId, amount: parseFloat(alarmForm.amount), active: true } : r));
                  setEditingAlarmId(null);
                } else {
                  setReminders([...reminders, { ...alarmForm, id: 'rem-' + Date.now(), amount: parseFloat(alarmForm.amount), active: true }]);
                }
                setAlarmForm({ title: '', beneficiary: '', amount: '', currency: 'USD', date: new Date().toISOString().split('T')[0], time: '12:00', frequency: 'once', soundType: 'beep' });
              }} className="bg-slate-800/40 border border-slate-800 rounded-xl p-4 space-y-3">
                <h3 className="font-bold text-sm text-white">{editingAlarmId ? 'Edit Alarm' : t.addAlarm}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input type="text" placeholder={t.alarmTitle} value={alarmForm.title} onChange={e => setAlarmForm({ ...alarmForm, title: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" required />
                  <input type="text" placeholder={t.beneficiary} value={alarmForm.beneficiary} onChange={e => setAlarmForm({ ...alarmForm, beneficiary: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" />
                  <div className="flex gap-2">
                    <input type="number" step="any" placeholder={t.amount} value={alarmForm.amount} onChange={e => setAlarmForm({ ...alarmForm, amount: e.target.value })} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" required />
                    <select value={alarmForm.currency} onChange={e => setAlarmForm({ ...alarmForm, currency: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-sm text-white">
                      {sortedCurrencies.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input type="date" value={alarmForm.date} onChange={e => setAlarmForm({ ...alarmForm, date: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-sm text-white" />
                    <input type="time" value={alarmForm.time} onChange={e => setAlarmForm({ ...alarmForm, time: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-sm text-white" />
                  </div>
                  <select value={alarmForm.frequency} onChange={e => setAlarmForm({ ...alarmForm, frequency: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white">
                    <option value="once">{t.freqOnce}</option>
                    <option value="daily">{t.freqDaily}</option>
                    <option value="weekly">{t.freqWeekly}</option>
                    <option value="monthly">{t.freqMonthly}</option>
                  </select>
                  <select value={alarmForm.soundType} onChange={e => setAlarmForm({ ...alarmForm, soundType: e.target.value })} className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white">
                    <option value="beep">{t.soundBeep}</option>
                    <option value="continuous">{t.soundContinuous}</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <button type="submit" className="flex-1 bg-amber-600 hover:bg-amber-500 text-white font-semibold py-2.5 rounded-xl text-sm transition">{editingAlarmId ? 'Update Alarm' : t.addAlarm}</button>
                  {editingAlarmId && <button type="button" onClick={() => setEditingAlarmId(null)} className="bg-slate-800 px-4 rounded-xl text-xs">{t.cancel}</button>}
                </div>
              </form>
            </div>
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-5">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
              <h2 className="font-bold text-base text-white flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                {t.excelExport}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">{t.fromDate}</label>
                  <input type="date" value={statementFrom} onChange={e => setStatementFrom(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">{t.toDate}</label>
                  <input type="date" value={statementTo} onChange={e => setStatementTo(e.target.value)} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" />
                </div>
                <div className="flex items-end">
                  <button onClick={exportFilteredStatement} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold py-2.5 rounded-xl transition">
                    {t.exportReport}
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <StickyNote className="w-4 h-4 text-amber-400" />
                  {t.notesTitle}
                </h3>
                <span className="text-xs text-emerald-400">{t.saved}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {notesList.map(note => (
                  <div key={note.id} className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-3.5 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-center">
                        <h4 className="font-bold text-sm text-white">{note.title}</h4>
                        <div className="flex gap-1">
                          <button onClick={() => { setEditingNoteId(note.id); setNoteForm(note); }} className="p-1 text-emerald-400 hover:bg-slate-700 rounded"><Edit2 className="w-3.5 h-3.5" /></button>
                          <button onClick={() => setNotesList(notesList.filter(n => n.id !== note.id))} className="p-1 text-rose-400 hover:bg-slate-700 rounded"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </div>
                      <p className="text-xs text-slate-300 whitespace-pre-line mt-2">{note.body}</p>
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={(e) => {
                e.preventDefault();
                if (!noteForm.title) return;
                if (editingNoteId) {
                  setNotesList(notesList.map(n => n.id === editingNoteId ? { ...noteForm, id: editingNoteId } : n));
                  setEditingNoteId(null);
                } else {
                  setNotesList([...notesList, { ...noteForm, id: 'n-' + Date.now() }]);
                }
                setNoteForm({ title: '', body: '' });
              }} className="bg-slate-800/40 border border-slate-800 rounded-xl p-4 space-y-3">
                <h4 className="font-bold text-sm text-white">{editingNoteId ? 'Edit Note' : t.addNote}</h4>
                <input type="text" placeholder={t.noteTitlePlaceholder} value={noteForm.title} onChange={e => setNoteForm({ ...noteForm, title: e.target.value })} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white" required />
                <textarea rows={4} placeholder={t.noteBodyPlaceholder} value={noteForm.body} onChange={e => setNoteForm({ ...noteForm, body: e.target.value })} className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-slate-200" />
                <div className="flex gap-2">
                  <button type="submit" className="flex-1 bg-amber-600 hover:bg-amber-500 text-white font-semibold py-2 rounded-xl text-sm">{editingNoteId ? 'Update Note' : t.addNote}</button>
                  {editingNoteId && <button type="button" onClick={() => setEditingNoteId(null)} className="bg-slate-800 px-4 rounded-xl text-xs">{t.cancel}</button>}
                </div>
              </form>
            </div>
          </div>
        )}
      </main>

      <nav className="fixed bottom-0 inset-x-0 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 z-40">
        <div className="max-w-4xl mx-auto grid grid-cols-7 py-2 text-center text-xs">
          <button onClick={() => setActiveTab('dashboard')} className={`flex flex-col items-center gap-1 py-1 ${activeTab === 'dashboard' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
            <Wallet className="w-4 h-4" /><span>{t.dashboard}</span>
          </button>
          <button onClick={() => setActiveTab('transactionsTab')} className={`flex flex-col items-center gap-1 py-1 ${activeTab === 'transactionsTab' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
            <Clock className="w-4 h-4" /><span>{t.transactionsTab}</span>
          </button>
          <button onClick={() => setActiveTab('currencies')} className={`flex flex-col items-center gap-1 py-1 ${activeTab === 'currencies' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
            <ArrowLeftRight className="w-4 h-4" /><span>{t.currencies}</span>
          </button>
          <button onClick={() => setActiveTab('accounts')} className={`flex flex-col items-center gap-1 py-1 ${activeTab === 'accounts' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
            <Landmark className="w-4 h-4" /><span>{t.accounts}</span>
          </button>
          <button onClick={() => setActiveTab('wealth')} className={`flex flex-col items-center gap-1 py-1 ${activeTab === 'wealth' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
            <Coins className="w-4 h-4" /><span>{t.wealth}</span>
          </button>
          <button onClick={() => setActiveTab('zakat')} className={`flex flex-col items-center gap-1 py-1 ${activeTab === 'zakat' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
            <ShieldCheck className="w-4 h-4" /><span>{t.zakat}</span>
          </button>
          <button onClick={() => setActiveTab('remindersTab')} className={`flex flex-col items-center gap-1 py-1 ${activeTab === 'remindersTab' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
            <Bell className="w-4 h-4" /><span>{t.remindersTab}</span>
          </button>
        </div>
      </nav>
    </div>
  );
}

function renderTxItem(tx, setEditingTxId, setTxForm, handleDeleteTransaction, t, goToDash = null) {
  return (
    <div key={tx.id} className="flex items-center justify-between bg-slate-800/50 border border-slate-800 rounded-xl p-3">
      <div className="flex items-center gap-3">
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${tx.type === 'expense' ? 'bg-rose-500/15 text-rose-400' : 'bg-emerald-500/15 text-emerald-400'}`}>
          {tx.type === 'expense' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
        </div>
        <div>
          <h4 className="text-sm font-medium text-white">{tx.title}</h4>
          <p className="text-xs text-slate-400">{tx.date}</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className={`font-bold text-sm ${tx.type === 'expense' ? 'text-rose-400' : 'text-emerald-400'}`}>
          {tx.type === 'expense' ? '-' : '+'}{tx.amount} {tx.currency}
        </span>
        <div className="flex gap-1">
          <button onClick={() => { setEditingTxId(tx.id); setTxForm(tx); if (goToDash) goToDash(); }} className="p-1.5 bg-slate-800 text-emerald-400 rounded-lg"><Edit2 className="w-3.5 h-3.5" /></button>
          <button onClick={() => handleDeleteTransaction(tx.id)} className="p-1.5 bg-slate-800 text-rose-400 rounded-lg"><Trash2 className="w-3.5 h-3.5" /></button>
        </div>
      </div>
    </div>
  );
}
